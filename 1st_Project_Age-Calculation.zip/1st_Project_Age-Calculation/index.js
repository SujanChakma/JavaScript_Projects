// Declare variable
let DobOpen = false;
let DOB; 
const SiconEl = document.getElementById("Sicon");
const ScontentEl = document.getElementById("Scontent");
const btnEl = document.getElementById("btn");
const datEl = document.getElementById("dat");
const Initial_contentEl = document.getElementById("Initial_content");
const Secondary_contentEl = document.getElementById("Secondary_content");
const time_contentEl = document.getElementById("time_content");

const yearEl = document.getElementById("year");
const monthsEl = document.getElementById("months");
const daysEl = document.getElementById("days");
const hoursEl = document.getElementById("hours");
const minutesEl = document.getElementById("minutes");
const secondsEl = document.getElementById("seconds");


// Declare Function for setting icon
const toggle = () => {
    // Adding condition for toggle
    if(DobOpen){
        ScontentEl.classList.add("hide"); /* hide is a class name 
        getting called from style.css */
    }else{
        ScontentEl.classList.remove("hide");
    }
    DobOpen = !DobOpen;
};

const MakeDoubleDigit = (number) => {
    return number > 9 ? number : `0${number}`;
};


// Declare function for add date button
const btnFnc = () => {
    DOB = datEl.value;
    if(DOB){
        Initial_contentEl.classList.add("hide");
        Secondary_contentEl.classList.remove("hide");
        updateAge();
        setInterval( () => updateAge(), 1000); // is used to set time interval
    }else{
        Initial_contentEl.classList.remove("hide");
        Secondary_contentEl.classList.add("hide");
        alert("Please Enter Date Of Birth First!!!!");
    }
    // console.log("Date of birth is :", DOB);
};

const updateAge = () => {
    const BD = new Date(DOB);
    const CurrentDate = new Date();
    const dateDiff = CurrentDate - BD;
    const year = Math.floor(dateDiff / (1000 * 60 * 60 * 24 * 365));
    const month = Math.floor((dateDiff / (1000 * 60 * 60 * 24 * 365)) % 12);
    const day = Math.floor(dateDiff / (1000 * 60 * 60 * 24)) % 30;
    const hour = Math.floor(dateDiff / (1000 * 60 * 60)) % 24;
    const minute = Math.floor(dateDiff / (1000 * 60)) % 60;
    const second = Math.floor(dateDiff / 1000) % 60;
    //console.log("Difference is :", dateDiff + "\n");

    //Change index html string using DOM
    yearEl.innerHTML = MakeDoubleDigit(year);
    monthsEl.innerHTML = MakeDoubleDigit(month);
    daysEl.innerHTML = MakeDoubleDigit(day);
    hoursEl.innerHTML = MakeDoubleDigit(hour);
    minutesEl.innerHTML = MakeDoubleDigit(minute);
    secondsEl.innerHTML = MakeDoubleDigit(second);
};

//btnFnc();


//updateAge();

// calling toggle function by using EventListener properties
SiconEl.addEventListener("click", toggle);
// active add date button by calling btnFnc function
btnEl.addEventListener("click", btnFnc);
