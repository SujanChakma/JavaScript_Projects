let banglaEl = document.getElementById("bangla");
let englishEl = document.getElementById("english");
let math1El = document.getElementById("math1");
let math2El = document.getElementById("math2");
let physicsEl = document.getElementById("physics");
let chemistryEl = document.getElementById("chemistry");
let biologyEl = document.getElementById("biology");
let sociologyEl = document.getElementById("sociology");
let religionEl = document.getElementById("religion");
let calculatebtnEl = document.getElementById("calculatebtn");

function resetdata() {
  const form = document.getElementById("form_call");
  form.reset();
}

let GP_calculation = () => {
  // Retrieve the value from the input field
  let bang = parseFloat(banglaEl.value) || 0;
  let eng = parseFloat(englishEl.value) || 0;
  let mat1 = parseFloat(math1El.value) || 0;
  let mat2 = parseFloat(math2El.value) || 0;
  let physcs = parseFloat(physicsEl.value) || 0;
  let chems = parseFloat(chemistryEl.value) || 0;
  let bio = parseFloat(biologyEl.value) || 0;
  let socio = parseFloat(sociologyEl.value) || 0;
  let relig = parseFloat(religionEl.value) || 0;

  let bang_gp,
    eng_gp,
    mat1_gp,
    mat2_gp,
    physcs_gp,
    chems_gp,
    bio_gp,
    socio_gp,
    relig_gp,
    sum,
    mult,
    GPA,
    result,
    gp;

  if (
    bang > 100 ||
    eng > 100 ||
    mat1 > 100 ||
    mat2 > 100 ||
    physcs > 100 ||
    chems > 100 ||
    bio > 100 ||
    socio > 100 ||
    relig > 100
  ) {
    alert("Please enter valid number");
  } else if (
    bang < 0 ||
    eng < 0 ||
    mat1 < 0 ||
    mat2 < 0 ||
    physcs < 0 ||
    chems < 0 ||
    bio < 0 ||
    socio < 0 ||
    relig < 0
  ) {
    alert("Please enter valid number");
  } else {
    sum = bang + eng + mat1 + mat2 + physcs + chems + bio + socio + relig;
    // console.log("Total value is :", sum);
    result = sum / 900;
    mult = result * 100;
    GPA = mult.toFixed(2);
    //console.log("Average value is :", GPA);

    // find gp
    if (GPA >= 80 && GPA <= 100) {
      gp = 5.0;
    } else if (GPA >= 70 && GPA < 80) {
      gp = 4.0;
    } else if (GPA >= 60 && GPA < 70) {
      gp = 3.5;
    } else if (GPA >= 50 && GPA < 60) {
      gp = 3.0;
    } else if (GPA >= 40 && GPA < 50) {
      gp = 2.0;
    } else if (GPA >= 33 && GPA < 40) {
      gp = 1.0;
    } else {
      gp = 0;
    }

    //Find Grade
    if (gp == 5.0) {
      document.getElementById(
        "content_set"
      ).innerHTML = `Your score is ${GPA}, you have gotten ${gp} out of 5.00 and your Grade is 'A+'`;
    } else if (gp >= 4.0 && gp < 5.0) {
      document.getElementById(
        "content_set"
      ).innerHTML = `Your score is ${GPA}, you have gotten ${gp} out of 5.00 and your Grade is 'A'`;
    } else if (gp >= 3.5 && gp < 4.0) {
      document.getElementById(
        "content_set"
      ).innerHTML = `Your score is ${GPA}, you have gotten ${gp} out of 5.00 and your Grade is 'A-'`;
    } else if (gp >= 3 && gp < 3.5) {
      document.getElementById(
        "content_set"
      ).innerHTML = `Your score is ${GPA}, you have gotten ${gp} out of 5.00 and your Grade is 'B'`;
    } else if (gp >= 2.0 && gp < 3.0) {
      document.getElementById(
        "content_set"
      ).innerHTML = `Your score is ${GPA}, you have gotten ${gp} out of 5.00 and your Grade is 'C'`;
    } else if (gp >= 1.0 && gp < 2.0) {
      document.getElementById(
        "content_set"
      ).innerHTML = `Your score is ${GPA}, you have gotten ${gp} out of 5.00 and your Grade is 'D'`;
    } else {
      document.getElementById(
        "content_set"
      ).innerHTML = `Your score is ${GPA}, you have gotten ${gp} out of 5.00 and your Grade is 'F'`;
    }
  }

  // reset input field
  resetdata();
};

calculatebtnEl.addEventListener("click", GP_calculation);
