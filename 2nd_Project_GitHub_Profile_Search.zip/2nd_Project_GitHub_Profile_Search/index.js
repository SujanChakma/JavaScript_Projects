
// Rest API GitHub Link: https://api.github.com/users/defunkt

const url ="https://api.github.com/users/"; // This is the default link of users of GitHub
const inputbtnEl = document.getElementById("search_input_box");
const srchbtnEl = document.getElementById("srchbtn");
const profilecontainerEl = document.getElementById("profilecontainer");
const loadingEl = document.getElementById("loading");
const PlaceHolderEl = inputbtnEl.placeholder; //Retrieve placeholder value

//Following code is used to Show profile view in HTML page
const GenerateProfile = (profile) => {
    return `
        <div class="GtH_profile">
        <div class="first_section">
          <div class="image_content">
            <img src= "${profile.avatar_url}" alt="hero image" class="heroimg" />
            <div class="image_content_h">
              <h2>${profile.name}</h2>
              <h2>${profile.login}</h2>
            </div>
          </div>
          <div class="profile_content">
            <button class="check_pf">
              <a href="${profile.html_url}">Check Profile</a>
            </button>
          </div>
        </div>
        <div class="second_section">
          <h1>About</h1>
          <h2>
          ${profile.bio}
          </h2>
        </div>
        <div class="third_section">
          <div class="third_section_first">
            <h1>Followers</h1>
            <h2>${profile.followers}</h2>
          </div>
          <div class="third_section_first">
            <h1>Following</h1>
            <h2>${profile.following}</h2>
          </div>
          <div class="third_section_first">
            <h1>Repos</h1>
            <h2>${profile.public_repos}</h2>
          </div>
        </div>
      </div>
    `;
};

//Following code is used to retrieve data from GitHub
const fetchProfile = async () => {
  //Following line retrieving data from Input Field of HTML page
    let UserName = inputbtnEl.value;
    //Following showing default message 
    loadingEl.innerText = "Loading...";
    loadingEl.style.color = "black";
  
    try {
      //This is searching data from GitHub
      //Here res holding an array of GitHub data
        const res = await fetch(`${url}${UserName}`);
        //This is converting irregular data into json data format
        const data = await res.json();
        if(data.bio){
          //if data.bio true then loading message getting hide
          loadingEl.innerText = "";
          //placing profile data to HTML page
          profilecontainerEl.innerHTML = GenerateProfile(data);
        }else{
          // showoing default message undefined if data not found
          loadingEl.innerHTML = data.message;
          loadingEl.style.color = "red";
          //if data not found profile section getting null
          profilecontainerEl.innerText = "";
          alert("Please Enter valid GitHub profile name..")
        }
    } catch (error) {
        console.log({error});
        //if error then show loading null
        loadingEl.innerText = "";
    }

    // Place placeholder value/text to html placehoder box
    document.getElementById("search_input_box").value = "";
    // document.getElementById("search_input_box").placeholder = `${PlaceHolderEl}`;
};

srchbtnEl.addEventListener("click", fetchProfile);