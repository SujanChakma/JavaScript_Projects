const buttonEl = document.getElementById("submit_btn");
let first_numberEl = document.getElementById("first_number");
let second_numberEl = document.getElementById("second_number");
const additionEl = document.getElementById("addition");
const subtractionEl = document.getElementById("subtraction");
const multiplicationEl = document.getElementById("multiplication");
const divisionEl = document.getElementById("division");
const get_inputValueEl = document.getElementById("get_inputValue");

let result,
  number1,
  number2,
  Got_Input_Value,
  mult,
  value,
  number = 0,
  dp_number = 0,
  dp_number2,
  add_result,
  addition = 0,
  subtraction = 0,
  score = 0,
  score1 = 0,
  count = 1,
  sub_result,
  mult_result,
  div_result,
  multiplication,
  division,
  correct_answer = 0,
  wrong_answer = 0,
  num_addition;

function getRandomInt1(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getRandomInt2(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

number1 = getRandomInt1();
number2 = getRandomInt2();

// Calculate Addition
function CalculateAddition() {
  add_result = number1 + number2;
  return add_result;
}
// Calculate Subtraction
function CalculateSubtractiontion() {
  sub_result = number1 - number2;
  return sub_result;
}
//Calculate Multiplication
function CalculateMultiplication() {
  mult_result = number1 * number2;
  return mult_result;
}

//Calculate Division
function CalculateDivision() {
  div_result = number1 / number2;
  return div_result;
}

//Addition menu
additionEl.addEventListener("click", function () {
  dp_number = 1;
  number1 = getRandomInt1(1, 50);
  number2 = getRandomInt2(1, 50);
  document.getElementById("question").innerHTML = `<h3>
            Q-${count}: What is the value of <span>${number1}</span> + <span>${number2}</span> ?
          </h3>`;
});

//Subtraction menu
subtractionEl.addEventListener("click", function () {
  dp_number = 2;
  number1 = getRandomInt1(10, 90);
  number2 = getRandomInt2(1, 70);
  document.getElementById("question").innerHTML = `<h3>
            Q-${count}: What is the value of <span>${number1}</span> - <span>${number2}</span> ?
          </h3>`;
});

//Multiplication menu
multiplicationEl.addEventListener("click", function () {
  dp_number = 3;
  number1 = getRandomInt1(1, 20);
  number2 = getRandomInt2(1, 20);
  document.getElementById("question").innerHTML = `<h3>
            Q-${count}: What is the value of <span>${number1}</span> * <span>${number2}</span> ?
          </h3>`;
});

//Division menu
divisionEl.addEventListener("click", function () {
  dp_number = 4;
  number1 = getRandomInt1(30, 100);
  number2 = getRandomInt2(2, 30);
  document.getElementById("question").innerHTML = `<h3>
            Q-${count}: What is the value of <span>${number1}</span> / <span>${number2}</span> ?
          </h3>`;
});

//submit button funtion
buttonEl.addEventListener("click", function () {
  if (get_inputValueEl.value == ``) {
    alert("Please Enter the result first!!!");
  } else if (dp_number == 1) {
    //for addition
    if (count <= 30) {
      addition = CalculateAddition();
      Got_Input_Value = document.getElementById("get_inputValue").value;
      if (addition == Got_Input_Value) {
        ++score;
        ++correct_answer;
        document.getElementById((id = "score_content")).innerText = score;
      } else {
        --score;
        ++wrong_answer;
        document.getElementById((id = "score_content")).innerText = score;
      }
      number1 = getRandomInt1(1, 50);
      number2 = getRandomInt2(1, 50);
      document.getElementById("question").innerHTML = `<h3>
                Q-${++count}: What is the value of <span>${number1}</span> + <span>${number2}</span> ?
              </h3>`;
      document.getElementById("reset_form").reset();
      if (count == 31) {
        document.getElementById(
          "answer_msg"
        ).innerHTML = `<p>Out of <span style="color:black; font-weight:bold;">${
          count - 1
        } </span> questions! Your correct answer is : <span style="color:black; font-weight:bold;">${correct_answer} </span>and wrong answer is : <span style="color:black; font-weight:bold;">${Math.abs(
          wrong_answer
        )}</span> .</p>`;
        document.getElementById("question").innerHTML = ``;
        document.getElementById("reset_form").innerHTML = ``;
        alert("Quiz is successfully completed!!");
      }
    } else {
      document.getElementById("reset_form").reset();
      alert("Quiz is successfully completed!!");
    }
  } else if (dp_number == 2) {
    //for subtraction
    if (count <= 30) {
      subtraction = CalculateSubtractiontion();
      Got_Input_Value = document.getElementById("get_inputValue").value;
      if (subtraction == Got_Input_Value) {
        ++score;
        ++correct_answer;
        document.getElementById((id = "score_content")).innerText = score;
      } else {
        --score;
        ++wrong_answer;
        document.getElementById((id = "score_content")).innerText = score;
      }
      number1 = getRandomInt1(10, 90);
      number2 = getRandomInt2(1, 70);
      document.getElementById("question").innerHTML = `<h3>
                Q- ${++count}: What is the value of <span>${number1}</span> - <span>${number2}</span> ?
              </h3>`;
      document.getElementById("reset_form").reset();
      if (count == 31) {
        document.getElementById(
          "answer_msg"
        ).innerHTML = `<p>Out of <span style="color:black; font-weight:bold;">${
          count - 1
        } </span> questions! Your correct answer is : <span style="color:black; font-weight:bold;">${correct_answer} </span>and wrong answer is : <span style="color:black; font-weight:bold;">${Math.abs(
          wrong_answer
        )}</span> .</p>`;
        document.getElementById("question").innerHTML = ``;
        document.getElementById("reset_form").innerHTML = ``;
        alert("Quiz is successfully completed!!");
      }
    } else {
      document.getElementById("reset_form").reset();
      alert("Quiz is successfully completed!!");
    }
  } else if (dp_number == 3) {
    //for multiplication
    if (count <= 30) {
      multiplication = CalculateMultiplication();
      Got_Input_Value = document.getElementById("get_inputValue").value;
      if (multiplication == Got_Input_Value) {
        ++score;
        ++correct_answer;
        document.getElementById((id = "score_content")).innerText = score;
      } else {
        --score;
        ++wrong_answer;
        document.getElementById((id = "score_content")).innerText = score;
      }
      number1 = getRandomInt1(1, 20);
      number2 = getRandomInt2(1, 20);
      document.getElementById("question").innerHTML = `<h3>
                Q- ${++count}: What is the value of <span>${number1}</span> * <span>${number2}</span> ?
              </h3>`;
      document.getElementById("reset_form").reset();
      if (count == 31) {
        document.getElementById(
          "answer_msg"
        ).innerHTML = `<p>Out of <span style="color:black; font-weight:bold;">${
          count - 1
        } </span> questions! Your correct answer is : <span style="color:black; font-weight:bold;">${correct_answer} </span>and wrong answer is : <span style="color:black; font-weight:bold;">${Math.abs(
          wrong_answer
        )}</span> .</p>`;
        document.getElementById("question").innerHTML = ``;
        document.getElementById("reset_form").innerHTML = ``;
        alert("Quiz is successfully completed!!");
      }
    } else {
      document.getElementById("reset_form").reset();
      alert("Quiz is successfully completed!!");
    }
  } else if (dp_number == 4) {
    //for division
    if (count <= 30) {
      division = parseInt(CalculateDivision());
      Got_Input_Value = document.getElementById("get_inputValue").value;
      if (division == Got_Input_Value) {
        ++score;
        ++correct_answer;
        document.getElementById((id = "score_content")).innerText = score;
      } else {
        --score;
        ++wrong_answer;
        document.getElementById((id = "score_content")).innerText = score;
      }
      number1 = getRandomInt1(30, 100);
      number2 = getRandomInt2(2, 15);
      document.getElementById("question").innerHTML = `<h3>
                Q- ${++count}: What is the value of <span>${number1}</span> / <span>${number2}</span> ?
              </h3>`;

      document.getElementById("reset_form").reset();

      if (count == 31) {
        document.getElementById(
          "answer_msg"
        ).innerHTML = `<p>Out of <span style="color:black; font-weight:bold;">${
          count - 1
        } </span> questions! Your correct answer is : <span style="color:black; font-weight:bold;">${correct_answer} </span>and wrong answer is : <span style="color:black; font-weight:bold;">${Math.abs(
          wrong_answer
        )}</span> .</p>`;
        document.getElementById("question").innerHTML = ``;
        document.getElementById("reset_form").innerHTML = ``;
        alert("Quiz is successfully completed!!");
        //alert("Quiz is successfully completed!!");
      }
    } else {
      document.getElementById("reset_form").reset();
      alert("Quiz is successfully completed!!");
    }
  }
});
